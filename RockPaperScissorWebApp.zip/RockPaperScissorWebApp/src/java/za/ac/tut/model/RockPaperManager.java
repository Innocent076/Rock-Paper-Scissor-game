/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.model;

/**
 *
 * @author SIBUSISO
 */
public class RockPaperManager implements RockPaperInterface{
    
   
    
    @Override
    public char generateSign() {
        char[] signs = {'R','P','S'};
        int index = (int) Math.floor(Math.random()*3);
        return signs[index];
    }

    @Override
    public String determineOutcome(char playerSign, char computerSign,String playerName,String computerName) {
        String winMessage;
        if(playerSign == 'R' && computerSign == 'P'){
            winMessage = computerName + " Wins";
        }else if(playerSign == 'R' && computerSign == 'S'){
            winMessage = playerName + " wins";
        }else if(playerSign == 'P' && computerSign == 'R'){
            winMessage = playerName + " wins";
        }else if(playerSign == 'P' && computerSign == 'S'){
            winMessage = computerName + " Wins";
        }else if(playerSign == 'S' && computerSign == 'R'){
            winMessage = computerName + " Wins";
        }else if(playerSign == 'S' && computerSign == 'P'){
            winMessage = playerName + " wins";
        }else{
            winMessage = "Tie";
        }
        return winMessage;
    }
    
}
